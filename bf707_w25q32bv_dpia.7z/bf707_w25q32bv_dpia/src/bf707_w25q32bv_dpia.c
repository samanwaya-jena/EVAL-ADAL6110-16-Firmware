/********************************************************************************
Copyright(c) 2014 Analog Devices, Inc. All Rights Reserved.

This software is proprietary.  By using this software you agree
to the terms of the associated Analog Devices License Agreement.

*********************************************************************************/

#include <sys/platform.h>

#include "common/flash.h"
#include "common/spi.h"


//#define USE_SOFT_SWITCHES

#include "common/dpia.c"

